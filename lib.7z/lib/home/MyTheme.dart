import 'package:flutter/material.dart';

class MyTheme {
  static const primaryColor = Color(0XFFB7935F);
  static ThemeData lightTheme = ThemeData(
    scaffoldBackgroundColor: Colors.transparent,//// to be clearrrr
    appBarTheme: AppBarTheme(
      color: Colors.transparent,
      centerTitle: true,
      elevation: 0,
      titleTextStyle: TextStyle(
        color: Colors.black,
        fontSize: 40,
      )
    ),
    canvasColor: primaryColor, /// to change color of botton NavigatioBar
    /// ///////////////////////////////////////////////////////////////////
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      selectedItemColor: Colors.black,
      unselectedItemColor: Colors.white,
      showSelectedLabels: true,
      showUnselectedLabels: false,
      backgroundColor: primaryColor,
    ),
    primaryColor: primaryColor,
  );
}
