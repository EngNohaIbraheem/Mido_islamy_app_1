import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:islamic_design/Quran/quranTab.dart';
import 'package:islamic_design/tasbeh/tasbehTab.dart';

import '../hadeth/hadethTab.dart';

class HomeScreen extends StatefulWidget {
  static const String routeName = 'HomeScreen';

  @override
  State<HomeScreen> createState() => _HomeScreenState();


}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
          image: DecorationImage(
              fit: BoxFit.fill,
              image: AssetImage("assets/images/background.png"))),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('islami'),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: selectedIndex,
          onTap: (index) {
            setState(() {
              selectedIndex = index;
            });
          },
          items: const [
            BottomNavigationBarItem(
                label: 'Quran',
                icon: ImageIcon(
                  AssetImage('assets/images/quran.png'),
                )), BottomNavigationBarItem(
                label: 'sebha',
                icon: ImageIcon(
                  AssetImage('assets/images/sebha.png'),
                )), BottomNavigationBarItem(
                label: 'hadeth',
                icon: ImageIcon(
                  AssetImage('assets/images/hadeth.png'),
                )),

          ],
        ),
        body: tabs[selectedIndex],
      ),
    );
  }

  List<Widget>tabs = [
    QuranTab(), TasbehTab(), hadethTab()
  ];
}

