import 'package:flutter/material.dart';
class TasbehTab extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.red,

    );
  }
}