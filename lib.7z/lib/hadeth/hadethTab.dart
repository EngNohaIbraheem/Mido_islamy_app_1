import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'hadethItem.dart';

class hadethTab extends StatefulWidget {
  @override
  State<hadethTab> createState() => _hadethTabState();
}

class _hadethTabState extends State<hadethTab> {
  List<HadethModel> allHadethItems = [];
  @override
  Widget build(BuildContext context) {
   if(allHadethItems.isEmpty)
    readHadethFile();
    return Container(
      ////color: Colors.pink,
      child: allHadethItems.isEmpty?
      Center(child: CircularProgressIndicator(),):
      ListView.builder(itemBuilder:(_,index){
        return Text(allHadethItems[index].title);
      },itemCount:allHadethItems.length,)

    );
  }
  void readHadethFile() async {
    List<HadethModel> allHadeth = []; /// before the void function
    var fileContent = await rootBundle.loadString('assets/files/ahadeth.txt');
    var allHadethContent = fileContent.split("#");
    for (int i = 0; i < allHadethContent.length; i++) {
      String singleHadethContent = allHadethContent[i];
      var singleHadethLines = singleHadethContent.trim().split('\r\n');
      String title = singleHadethContent[0];      /// to become atitle of hadeth [0]
      singleHadethLines.removeAt(0);
      String content = singleHadethLines.join("\n");      /// join lines with them
      HadethModel hadeth = HadethModel(title: title,
          content: content);
      allHadeth.add(hadeth);
    }
    setState(() {
      allHadethItems = allHadeth;
    });
  }
}
