class HadethModel{
  String title;
  String content;
  HadethModel({required this.content,required this.title});

}