import 'package:flutter/material.dart';
import 'package:islamic_design/SuraDetails/SuraDetailsScreen.dart';
import 'package:islamic_design/home/HomeScreen.dart';
import 'package:islamic_design/home/MyTheme.dart';

void main() {
  runApp( MyApplication());
}

class MyApplication extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: HomeScreen.routeName,
      routes: {
        HomeScreen.routeName:(_)=>HomeScreen(),
        SuraDetailsScreen.routeName:(_)=>SuraDetailsScreen(),

      },
      theme: MyTheme.lightTheme,

    );
  }
}

